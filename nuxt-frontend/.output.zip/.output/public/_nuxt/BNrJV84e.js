import e from"./w_pA3iMo.js";import{c as o,b as r,o as t}from"./DIQ-zLpi.js";import"./70IrwKbg.js";const p={__name:"index",setup(a){return(c,n)=>(t(),o("div",null,[r(e)]))}};export{p as default};
