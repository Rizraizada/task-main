import{U as e,V as r}from"./DIQ-zLpi.js";import{u as o}from"./70IrwKbg.js";const f=e((t,s)=>{if(!o().user)return r("/login")});export{f as default};
